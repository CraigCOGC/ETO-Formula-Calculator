import val

def ohmcalc():
	val.resistance = (val.voltage / val.current)
	print(val.resistance)

def voltcalc():
	val.voltage = (val.current * val.resistance)
	print(val.voltage)

def ampcalc():
	val.current = (val.voltage / val.resistance)
	print(val.current)

def powcalc():
	val.power = (val.current * val.voltage)
	print(val.power)

def pownoi():
	val.power = ((val.voltage ** 2) / val.resistance)
	print(val.power)

def pownov():
	val.power = ((val.current ** 2) * val.resistance)
	print(val.power)

def enercalc():
	val.energy = (val.power * val.time)
	print(val.energy)

def chrgcalc():
	val.charge = (val.capacitance * val.voltage)
	print(val.charge)

def chrgtime():
	val.charge = (val.current * val.time)
	print(val.charge)

def capcalc():
	val.capacitance = (val.charge / val.voltage)
	print(val.capacitance)
